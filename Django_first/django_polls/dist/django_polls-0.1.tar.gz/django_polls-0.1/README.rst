============
django-polls
============

django-polls is a Django app to conduct web-based polls.

Quick start
-----------

1. Add "django_polls" to INSTALLED_APPS
2. Include the polls URLs in urls.py
3. Run migrations
4. Visit /polls/ to participate